#!/usr/bin/env python3
"""Generate architecture diagram SVG (no dependencies)."""

import os

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'architecture.svg')

content = '''<?xml version="1.0" encoding="UTF-8" standalone="no"?>
<svg width="1400" height="500" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <marker id="arrow" markerWidth="10" markerHeight="7"
            refX="10" refY="3.5" orient="auto">
      <polygon points="0 0, 10 3.5, 0 7" fill="#555"/>
    </marker>
    <style type="text/css">
      .node { fill: #e1f5fe; stroke: #0288d1; stroke-width: 2; rx: 8; ry: 8; }
      .text { font-family: Arial, sans-serif; font-size: 11px; fill: #333; }
      .arrow { stroke: #555; stroke-width: 2; fill: none; marker-end: url(#arrow); }
    </style>
  </defs>

  <!-- Nodes -->
  <rect class="node" x="50" y="220" width="140" height="40"/>
  <text class="text" x="120" y="245" text-anchor="middle">Local Python Code</text>

  <rect class="node" x="250" y="220" width="110" height="40"/>
  <text class="text" x="305" y="245" text-anchor="middle">AST Parser</text>

  <rect class="node" x="420" y="220" width="100" height="40"/>
  <text class="text" x="470" y="245" text-anchor="middle">Delta-Sync</text>

  <rect class="node" x="580" y="130" width="120" height="40"/>
  <text class="text" x="640" y="155" text-anchor="middle">LLM Distiller</text>

  <rect class="node" x="580" y="310" width="110" height="40"/>
  <text class="text" x="635" y="335" text-anchor="middle">Local Cache</text>

  <rect class="node" x="750" y="220" width="140" height="40"/>
  <text class="text" x="820" y="245" text-anchor="middle">Semantic Summary</text>

  <rect class="node" x="950" y="220" width="110" height="40"/>
  <text class="text" x="1005" y="245" text-anchor="middle">ONNX Embedder</text>

  <rect class="node" x="1120" y="220" width="100" height="40"/>
  <text class="text" x="1170" y="245" text-anchor="middle">DuckDB VSS</text>

  <rect class="node" x="1290" y="210" width="140" height="50"/>
  <text class="text" x="1360" y="240" text-anchor="middle">Semantic Search</text>
  <text class="text" x="1360" y="255" text-anchor="middle">/ JSON API</text>

  <!-- Arrows -->
  <line class="arrow" x1="190" y1="240" x2="250" y2="240"/>
  <line class="arrow" x1="360" y1="240" x2="420" y2="240"/>
  <line class="arrow" x1="480" y1="240" x2="580" y2="170"/>
  <line class="arrow" x1="480" y1="260" x2="580" y2="310"/>
  <line class="arrow" x1="640" y1="150" x2="750" y2="240"/>
  <line class="arrow" x1="640" y1="310" x2="750" y2="260"/>
  <line class="arrow" x1="890" y1="240" x2="950" y2="240"/>
  <line class="arrow" x1="1060" y1="240" x2="1120" y2="240"/>
  <line class="arrow" x1="1220" y1="240" x2="1290" y2="240"/>

</svg>'''

with open(out, 'w') as f:
    f.write(content)
print(f"Saved {out}")
